﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace angular_demo.session14
{
    public class EmployeeModel
    {
        public int Id { set; get; }
        public string Name { set; get; }
        public int Salary { set; get; }
        public string Gender { set; get; }
        public DateTime BirthDay { set; get; }

    }
}